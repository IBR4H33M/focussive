import{D as A,d as R}from"./storage-BjqeIk3m.js";const E=["Focus is a muscle. Every time you resist a distraction, you make it stronger.","You do not rise to the level of your goals. You fall to the level of your systems. — James Clear","The secret of getting ahead is getting started. — Mark Twain","It is not that we have a short time to live, but that we waste a lot of it. — Seneca","Action is the foundational key to all success. — Pablo Picasso","Do what you have to do until you can do what you want to do. — Oprah Winfrey","Starve your distractions, feed your focus.","Your future is created by what you do today, not tomorrow.","Deep work is the ability to focus without distraction on a cognitively demanding task. — Cal Newport","Stay focused, go after your dreams, and keep moving toward your goals.","You can have results or excuses. Not both.","Small disciplines repeated with consistency every day lead to great achievements.","Don't count the days, make the days count. — Muhammad Ali","Discipline is choosing between what you want now and what you want most. — Abraham Lincoln","Turn down the noise. Focus on what truly moves the needle."];let n=null,v="",k="",b=null,y=5;chrome.runtime.onMessage.addListener((t,e,o)=>{t.type==="SHOW_OVERLAY"&&T(t.sessionId,t.websiteName,t.allowBreaks??!1,t.remainingBreakSeconds??0,t.settings),t.type==="HIDE_OVERLAY"&&F()});let u="idle",l=1,c=1,h=!1,x=0,i=A,a="";async function T(t,e,o,s,d){if(!n){if(v=t,k=e,x=Math.floor(s/60),h=o&&x>0,u="idle",l=1,c=1,d)i=d;else try{i=await R()}catch{i=A}if(i.overlay_quote_enabled&&E.length>0){const m=Math.floor(Math.random()*E.length);a=E[m]}else a="";y=i.auto_close_seconds||15,n=document.createElement("div"),n.id="focussive-violation-overlay",W(n),document.body.appendChild(n),g(),i.sound_enabled&&q(),i.auto_close_tab&&Y()}}function f(){b&&(clearInterval(b),b=null)}function Y(){f(),b=setInterval(()=>{y-=1;const t=document.getElementById("foc-countdown-number");t&&(t.textContent=String(y)),y<=0&&(f(),chrome.runtime.sendMessage({type:"CLOSE_TAB"}))},1e3)}function F(){f(),n&&(n.remove(),n=null)}function O(t){return t?t.startsWith("http://")||t.startsWith("https://")?t:t.includes("dog-really")?chrome.runtime.getURL("blockimages/dog-really.gif"):t.includes("dont-answer")?chrome.runtime.getURL("blockimages/dont-answer.gif"):chrome.runtime.getURL("blockimages/cat-no.gif"):chrome.runtime.getURL("blockimages/cat-no.gif")}function g(){n&&(u==="idle"?D():u==="selectBreak"?_("break"):u==="selectAllow"&&_("allow"))}function D(){var s,d,m;if(!n)return;const t=i.overlay_gif_enabled?O(i.overlay_gif_url):null;let e=a,o="";if(a.includes(" — ")){const r=a.split(" — ");e=r[0],o=r.slice(1).join(" — ")}else if(a.includes(" – ")){const r=a.split(" – ");e=r[0],o=r.slice(1).join(" – ")}else if(a.includes(" - ")){const r=a.split(" - ");e=r[0],o=r.slice(1).join(" - ")}n.innerHTML=`
    <div style="text-align:center; padding:24px 20px; max-width:440px; margin:auto; width:100%; box-sizing:border-box; flex-shrink:0;">
      <h2 style="color:#FFFFFF; font-size:24px; font-weight:700; margin:0 0 6px; letter-spacing:0.3px; flex-shrink:0;">
        You are getting distracted
      </h2>
      <p style="color:rgba(255,255,255,0.7); font-size:14px; font-weight:400; margin:0 0 16px; line-height:1.4; flex-shrink:0;">
        You're visiting <strong style="color:#FFFFFF; font-weight:600;">${k}</strong> during a focus session
      </p>

      ${t?`
        <div style="margin:0 auto 16px auto; width:160px; height:160px; max-width:70vw; max-height:22vh; border-radius:16px; overflow:hidden; border:none; box-shadow:0 10px 30px rgba(0,0,0,0.6); flex-shrink:0;">
          <img src="${t}" alt="Block" style="width:100%; height:100%; object-fit:cover; display:block;" />
        </div>
      `:""}

      ${i.overlay_quote_enabled&&a?`
        <div style="margin:0 0 16px; padding:0 8px; text-align:center; flex-shrink:0;">
          <p style="font-style:italic; color:#86EFAC; font-size:19px; font-weight:700; margin:0; line-height:1.35; letter-spacing:-0.2px; text-shadow:0 2px 8px rgba(0,0,0,0.6);">
            "${e}"
          </p>
          ${o?`
            <div style="color:#86EFAC; font-size:13px; font-weight:400; margin-top:6px; font-style:normal; letter-spacing:0.3px; opacity:0.85;">
              — ${o}
            </div>
          `:""}
        </div>
      `:""}

      ${i.auto_close_tab?`
        <!-- Large countdown container -->
        <div id="foc-countdown-box" style="margin: 0 0 16px; background:rgba(0,0,0,0.5); border:none; border-radius:14px; padding:10px 14px; text-align:center; flex-shrink:0;">
          <div style="font-size:10px; font-weight:700; letter-spacing:1.5px; text-transform:uppercase; color:rgba(255,255,255,0.6); margin-bottom:2px;">
            CLOSING TAB IN
          </div>
          <div id="foc-countdown-number" style="font-size:46px; font-weight:800; color:#FF6B6B; font-family:-apple-system, BlinkMacSystemFont, monospace; line-height:1.1;">
            ${y}
          </div>
          <div style="font-size:11px; color:rgba(255,255,255,0.45); margin-top:2px;">
            seconds · Select an option below to stay
          </div>
        </div>
      `:""}

      <div style="display:flex; flex-direction:column; gap:10px; width:100%; flex-shrink:0;">

        <!-- Exit / Close Tab -->
        <button id="foc-exit" style="${w} background:rgba(255,255,255,0.12); border:none; color:#FFFFFF;">
          Close tab now
        </button>

        <!-- Take a break — only if break time available -->
        ${h?`<button id="foc-break" style="${w} background:rgba(255,255,255,0.12); border:none; color:#FFFFFF; justify-content:space-between !important; padding:12px 20px !important;">
               <span style="font-size:15px; font-weight:500; color:#FFFFFF;">Take a break?</span>
               <span style="font-size:15px; font-weight:600; color:#FFFFFF;">${x} min</span>
             </button>`:""}

        <!-- Allow anyway -->
        <button id="foc-allow" style="${w} background:#D34545; border:none; color:#FFFFFF;">
          Allow anyway
        </button>

      </div>
    </div>
  `,(s=document.getElementById("foc-exit"))==null||s.addEventListener("click",()=>{f(),chrome.runtime.sendMessage({type:"CLOSE_TAB"})}),h&&((d=document.getElementById("foc-break"))==null||d.addEventListener("click",()=>{f(),u="selectBreak",l=1,g()})),(m=document.getElementById("foc-allow"))==null||m.addEventListener("click",()=>{f(),u="selectAllow",c=1,g()}),M(["foc-exit",...h?["foc-break"]:[],"foc-allow"])}function _(t){var S,B,L,I;if(!n)return;const e=t==="break",o=e?x:5,s=e?l:c,d=e?"Take a break":"WARNING!",m=e?"Breaks don't count as<br />distracted time.":"You are getting distracted within a focus session!",r=e?"#90EE90":"#FF6B6B",$=e?"rgba(255,255,255,0.7)":"rgba(255,180,180,0.85)",z=e?`Start ${s} min break`:`Allow ${s} min`,C=e?"background:#16652D; border:none; color:#FFFFFF;":"background:#D34545; border:none; color:#FFFFFF;";n.innerHTML=`
    <div style="text-align:center; padding:32px 24px; max-width:380px; margin:auto; width:100%; box-sizing:border-box; flex-shrink:0;">
      <h2 style="color:${r}; font-size:26px; font-weight:700; margin:0 0 8px;">${d}</h2>
      <p style="color:${$}; font-size:13px; font-weight:400; margin:0 0 24px; line-height:1.5;">${m}</p>

      <!-- Picker -->
      <div style="display:flex; flex-direction:column; align-items:center; margin-bottom:28px; flex-shrink:0;">
        <button id="foc-up" style="background:none; border:none; color:rgba(255,255,255,0.7); font-size:24px; cursor:pointer; padding:8px 48px; transition:color 0.15s;">▲</button>
        <div>
          <span id="foc-num" style="color:white; font-size:72px; font-weight:200; line-height:1;">${s}</span>
          <div style="color:rgba(255,255,255,0.5); font-size:15px; margin-top:-6px;">min</div>
        </div>
        <button id="foc-down" style="background:none; border:none; color:rgba(255,255,255,0.7); font-size:24px; cursor:pointer; padding:8px 48px; transition:color 0.15s;">▼</button>
      </div>

      <div style="display:flex; flex-direction:column; gap:10px; width:100%; flex-shrink:0;">
        <button id="foc-confirm" style="${w} ${C}">${z}</button>
        <button id="foc-back" style="background:none; border:none; color:rgba(255,255,255,0.4); font-size:13px; cursor:pointer; padding:10px;">&lt; Back</button>
      </div>
    </div>
  `,(S=document.getElementById("foc-up"))==null||S.addEventListener("click",()=>{e?l=Math.min(l+1,o):c=Math.min(c+1,o),g()}),(B=document.getElementById("foc-down"))==null||B.addEventListener("click",()=>{e?l=Math.max(l-1,1):c=Math.max(c-1,1),g()}),["foc-up","foc-down"].forEach(N=>{const p=document.getElementById(N);p&&(p.addEventListener("mouseenter",()=>{p.style.color="white",p.style.transform="scale(1.15)"}),p.addEventListener("mouseleave",()=>{p.style.color="rgba(255,255,255,0.7)",p.style.transform="scale(1)"}))}),(L=document.getElementById("foc-confirm"))==null||L.addEventListener("click",()=>{e?U():j()}),M(["foc-confirm"]),(I=document.getElementById("foc-back"))==null||I.addEventListener("click",()=>{u="idle",g()})}function U(){chrome.runtime.sendMessage({type:"START_BREAK",sessionId:v,minutes:l}),F()}function j(){const t=c*60;chrome.runtime.sendMessage({type:"VIOLATION_RESPONSE",sessionId:v,websiteName:k,action:"allow_anyway",durationSeconds:t}),F(),setTimeout(()=>{T(v,k,h,x*60,i)},t*1e3)}const w=`
  width:100% !important; min-height:46px !important; height:auto !important;
  padding:12px 20px !important; border-radius:12px !important; border:none !important; outline:none !important;
  font-size:15px !important; font-weight:600 !important; cursor:pointer !important;
  font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif !important;
  box-sizing:border-box !important; text-align:center !important; line-height:1.3 !important;
  display:flex !important; align-items:center !important; justify-content:center !important;
  flex-shrink:0 !important; max-height:none !important;
  transition: transform 0.12s, opacity 0.12s !important;
`;function W(t){t.style.cssText=`
    position: fixed !important;
    top: 0 !important; left: 0 !important;
    width: 100vw !important; height: 100vh !important;
    background: rgba(14, 14, 18, 0.95) !important;
    z-index: 2147483647 !important;
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important;
    justify-content: flex-start !important;
    overflow-y: auto !important;
    overflow-x: hidden !important;
    padding: 32px 16px !important;
    box-sizing: border-box !important;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
    backdrop-filter: blur(16px) !important;
    -webkit-backdrop-filter: blur(16px) !important;
  `}function M(t){t.forEach(e=>{const o=document.getElementById(e);o&&(o.addEventListener("mouseenter",()=>{o.style.transform="translateY(-1px) scale(1.02)",o.style.opacity="0.9"}),o.addEventListener("mouseleave",()=>{o.style.transform="translateY(0) scale(1)",o.style.opacity="1"}),o.addEventListener("mousedown",()=>{o.style.transform="translateY(0) scale(0.98)"}),o.addEventListener("mouseup",()=>{o.style.transform="translateY(-1px) scale(1.02)"}))})}function q(){try{const t=new AudioContext,e=t.createOscillator(),o=t.createGain();e.connect(o),o.connect(t.destination),e.frequency.value=650,e.type="sine",o.gain.value=.25,e.start(),setTimeout(()=>{e.stop(),t.close()},400)}catch{}}window.addEventListener("beforeunload",()=>{F()});
