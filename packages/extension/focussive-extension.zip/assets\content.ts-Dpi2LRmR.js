import{D as A,d as R}from"./storage-BjqeIk3m.js";const E=["Focus is a muscle. Every time you resist a distraction, you make it stronger.","You do not rise to the level of your goals. You fall to the level of your systems. — James Clear","The secret of getting ahead is getting started. — Mark Twain","It is not that we have a short time to live, but that we waste a lot of it. — Seneca","Action is the foundational key to all success. — Pablo Picasso","Do what you have to do until you can do what you want to do. — Oprah Winfrey","Starve your distractions, feed your focus.","Your future is created by what you do today, not tomorrow.","Deep work is the ability to focus without distraction on a cognitively demanding task. — Cal Newport","Stay focused, go after your dreams, and keep moving toward your goals.","You can have results or excuses. Not both.","Small disciplines repeated with consistency every day lead to great achievements.","Don't count the days, make the days count. — Muhammad Ali","Discipline is choosing between what you want now and what you want most. — Abraham Lincoln","Turn down the noise. Focus on what truly moves the needle."];let n=null,v="",F="",x=null,y=5;chrome.runtime.onMessage.addListener((e,t,o)=>{e.type==="SHOW_OVERLAY"&&T(e.sessionId,e.websiteName,e.allowBreaks??!1,e.remainingBreakSeconds??0,e.settings),e.type==="HIDE_OVERLAY"&&k()});let f="idle",l=1,c=1,b=!1,h=0,i=A,r="";async function T(e,t,o,s,d){if(!n){if(v=e,F=t,h=Math.floor(s/60),b=o&&h>0,f="idle",l=1,c=1,d)i=d;else try{i=await R()}catch{i=A}if(i.overlay_quote_enabled&&E.length>0){const p=Math.floor(Math.random()*E.length);r=E[p]}else r="";y=i.auto_close_seconds||15,n=document.createElement("div"),n.id="focussive-violation-overlay",j(n),document.body.appendChild(n),m(),i.sound_enabled&&q(),i.auto_close_tab&&Y()}}function g(){x&&(clearInterval(x),x=null)}function Y(){g(),x=setInterval(()=>{y-=1;const e=document.getElementById("foc-countdown-number");e&&(e.textContent=String(y)),y<=0&&(g(),chrome.runtime.sendMessage({type:"CLOSE_TAB"}))},1e3)}function k(){g(),n&&(n.remove(),n=null)}function O(e){return e?e.startsWith("http://")||e.startsWith("https://")?e:e.includes("dog-really")?chrome.runtime.getURL("blockimages/dog-really.gif"):e.includes("dont-answer")?chrome.runtime.getURL("blockimages/dont-answer.gif"):chrome.runtime.getURL("blockimages/cat-no.gif"):chrome.runtime.getURL("blockimages/cat-no.gif")}function m(){n&&(f==="idle"?D():f==="selectBreak"?_("break"):f==="selectAllow"&&_("allow"))}function D(){var s,d,p;if(!n)return;const e=i.overlay_gif_enabled?O(i.overlay_gif_url):null;let t=r,o="";if(r.includes(" — ")){const a=r.split(" — ");t=a[0],o=a.slice(1).join(" — ")}else if(r.includes(" – ")){const a=r.split(" – ");t=a[0],o=a.slice(1).join(" – ")}else if(r.includes(" - ")){const a=r.split(" - ");t=a[0],o=a.slice(1).join(" - ")}n.innerHTML=`
    <div style="text-align:center; padding:32px 24px; max-width:440px; margin:0 auto; width:100%; box-sizing:border-box;">
      <h2 style="color:#FFFFFF; font-size:26px; font-weight:700; margin:0 0 8px; letter-spacing:0.3px;">
        You are getting distracted
      </h2>
      <p style="color:rgba(255,255,255,0.7); font-size:14px; font-weight:400; margin:0 0 18px; line-height:1.4;">
        You're visiting <strong style="color:#FFFFFF; font-weight:600;">${F}</strong> during a focus session
      </p>

      ${e?`
        <div style="margin:0 auto 20px auto; width:200px; height:200px; max-width:85vw; border-radius:16px; overflow:hidden; border:none; box-shadow:0 10px 30px rgba(0,0,0,0.6);">
          <img src="${e}" alt="Block" style="width:100%; height:100%; object-fit:cover; display:block;" />
        </div>
      `:""}

      ${i.overlay_quote_enabled&&r?`
        <div style="margin:0 0 22px; padding:0 8px; text-align:center;">
          <p style="font-style:italic; color:#86EFAC; font-size:24px; font-weight:700; margin:0; line-height:1.35; letter-spacing:-0.2px; text-shadow:0 2px 8px rgba(0,0,0,0.6);">
            "${t}"
          </p>
          ${o?`
            <div style="color:#86EFAC; font-size:14px; font-weight:400; margin-top:8px; font-style:normal; letter-spacing:0.3px; opacity:0.85;">
              — ${o}
            </div>
          `:""}
        </div>
      `:""}

      ${i.auto_close_tab?`
        <!-- Large countdown container -->
        <div id="foc-countdown-box" style="margin: 0 0 20px; background:rgba(0,0,0,0.5); border:none; border-radius:14px; padding:12px 16px; text-align:center;">
          <div style="font-size:10px; font-weight:700; letter-spacing:1.5px; text-transform:uppercase; color:rgba(255,255,255,0.6); margin-bottom:2px;">
            CLOSING TAB IN
          </div>
          <div id="foc-countdown-number" style="font-size:54px; font-weight:800; color:#FF6B6B; font-family:-apple-system, BlinkMacSystemFont, monospace; line-height:1.1;">
            ${y}
          </div>
          <div style="font-size:11px; color:rgba(255,255,255,0.45); margin-top:2px;">
            seconds · Select an option below to stay
          </div>
        </div>
      `:""}

      <div style="display:flex; flex-direction:column; gap:10px;">

        <!-- Exit / Close Tab -->
        <button id="foc-exit" style="${w} background:rgba(255,255,255,0.12); border:none; color:#FFFFFF;">
          Close tab now
        </button>

        <!-- Take a break — only if break time available -->
        ${b?`<button id="foc-break" style="${w} background:rgba(255,255,255,0.12); border:none; color:#FFFFFF; display:flex; justify-content:space-between; align-items:center; padding:14px 20px;">
               <span style="font-size:15px; font-weight:500; color:#FFFFFF;">Take a break?</span>
               <span style="font-size:16px; font-weight:600; color:#FFFFFF;">${h} min</span>
             </button>`:""}

        <!-- Allow anyway -->
        <button id="foc-allow" style="${w} background:#8B1E1E; border:none; color:#FFFFFF;">
          Allow anyway
        </button>

      </div>
    </div>
  `,(s=document.getElementById("foc-exit"))==null||s.addEventListener("click",()=>{g(),chrome.runtime.sendMessage({type:"CLOSE_TAB"})}),b&&((d=document.getElementById("foc-break"))==null||d.addEventListener("click",()=>{g(),f="selectBreak",l=1,m()})),(p=document.getElementById("foc-allow"))==null||p.addEventListener("click",()=>{g(),f="selectAllow",c=1,m()}),M(["foc-exit",...b?["foc-break"]:[],"foc-allow"])}function _(e){var B,S,L,I;if(!n)return;const t=e==="break",o=t?h:5,s=t?l:c,d=t?"Take a break":"WARNING!",p=t?"Breaks don't count as<br />distracted time.":"You are getting distracted within a focus session!",a=t?"#90EE90":"#FF6B6B",$=t?"rgba(255,255,255,0.7)":"rgba(255,180,180,0.85)",z=t?`Start ${s} min break`:`Allow ${s} min`,C=t?"background:#16652D; border:none; color:#FFFFFF;":"background:#8B1E1E; border:none; color:#FFFFFF;";n.innerHTML=`
    <div style="text-align:center; padding:36px 28px; max-width:380px; margin:0 auto; width:100%;">
      <h2 style="color:${a}; font-size:26px; font-weight:700; margin:0 0 8px;">${d}</h2>
      <p style="color:${$}; font-size:13px; font-weight:400; margin:0 0 28px; line-height:1.5;">${p}</p>

      <!-- Picker -->
      <div style="display:flex; flex-direction:column; align-items:center; margin-bottom:32px;">
        <button id="foc-up" style="background:none; border:none; color:rgba(255,255,255,0.7); font-size:24px; cursor:pointer; padding:8px 48px; transition:color 0.15s;">▲</button>
        <div>
          <span id="foc-num" style="color:white; font-size:76px; font-weight:200; line-height:1;">${s}</span>
          <div style="color:rgba(255,255,255,0.5); font-size:15px; margin-top:-6px;">min</div>
        </div>
        <button id="foc-down" style="background:none; border:none; color:rgba(255,255,255,0.7); font-size:24px; cursor:pointer; padding:8px 48px; transition:color 0.15s;">▼</button>
      </div>

      <div style="display:flex; flex-direction:column; gap:10px;">
        <button id="foc-confirm" style="${w} ${C}">${z}</button>
        <button id="foc-back" style="background:none; border:none; color:rgba(255,255,255,0.4); font-size:13px; cursor:pointer; padding:10px;">&lt; Back</button>
      </div>
    </div>
  `,(B=document.getElementById("foc-up"))==null||B.addEventListener("click",()=>{t?l=Math.min(l+1,o):c=Math.min(c+1,o),m()}),(S=document.getElementById("foc-down"))==null||S.addEventListener("click",()=>{t?l=Math.max(l-1,1):c=Math.max(c-1,1),m()}),["foc-up","foc-down"].forEach(N=>{const u=document.getElementById(N);u&&(u.addEventListener("mouseenter",()=>{u.style.color="white",u.style.transform="scale(1.15)"}),u.addEventListener("mouseleave",()=>{u.style.color="rgba(255,255,255,0.7)",u.style.transform="scale(1)"}))}),(L=document.getElementById("foc-confirm"))==null||L.addEventListener("click",()=>{t?U():W()}),M(["foc-confirm"]),(I=document.getElementById("foc-back"))==null||I.addEventListener("click",()=>{f="idle",m()})}function U(){chrome.runtime.sendMessage({type:"START_BREAK",sessionId:v,minutes:l}),k()}function W(){const e=c*60;chrome.runtime.sendMessage({type:"VIOLATION_RESPONSE",sessionId:v,websiteName:F,action:"allow_anyway",durationSeconds:e}),k(),setTimeout(()=>{T(v,F,b,h*60,i)},e*1e3)}const w=`
  width:100%; padding:13px 20px; border-radius:12px; border:none; outline:none;
  font-size:14px; font-weight:600; cursor:pointer;
  font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
  box-sizing:border-box; text-align:center;
  transition: transform 0.12s, opacity 0.12s;
`;function j(e){e.style.cssText=`
    position: fixed;
    top: 0; left: 0;
    width: 100vw; height: 100vh;
    background: rgba(14, 14, 18, 0.94);
    z-index: 2147483647;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
  `}function M(e){e.forEach(t=>{const o=document.getElementById(t);o&&(o.addEventListener("mouseenter",()=>{o.style.transform="translateY(-1px) scale(1.02)",o.style.opacity="0.9"}),o.addEventListener("mouseleave",()=>{o.style.transform="translateY(0) scale(1)",o.style.opacity="1"}),o.addEventListener("mousedown",()=>{o.style.transform="translateY(0) scale(0.98)"}),o.addEventListener("mouseup",()=>{o.style.transform="translateY(-1px) scale(1.02)"}))})}function q(){try{const e=new AudioContext,t=e.createOscillator(),o=e.createGain();t.connect(o),o.connect(e.destination),t.frequency.value=650,t.type="sine",o.gain.value=.25,t.start(),setTimeout(()=>{t.stop(),e.close()},400)}catch{}}window.addEventListener("beforeunload",()=>{k()});
